> **ATENÇÃO:** este documento descreve o fluxo antigo de autenticação por e-mail/UUID. Para a versão 1.5.1, ignore as etapas de criação manual de usuários e vínculos. Use `README-1.5.1-OPERADORES-REMOTOS.md`.

# ALENGO ESPETINHOS 1.5.0 — Acesso remoto de atendentes

## O que esta versão acrescenta

- Mantém o servidor HTTP local na porta 8765 e o banco SQLite como fonte oficial.
- Mantém o aplicativo Android atual sem alterações.
- Mantém o acesso Web local em `/mobile/`.
- Acrescenta acesso Web remoto via Supabase Auth e fila de comandos.
- O Windows inicia as conexões de saída com o Supabase; não exige abrir a porta 8765 no roteador.
- O Web remoto guarda comandos pendentes no IndexedDB quando o celular está sem internet e os reenvia quando a conexão retorna.
- O pedido só é confirmado depois de o Windows processá-lo e gravá-lo no SQLite.
- Pedidos, cancelamentos e alterações de entrega passam por validação local; preços, disponibilidade e estoque são revalidados no Windows.
- O snapshot remoto contém somente mesas, catálogo e pedidos do atendente vinculado. Não publica caixa, relatórios, configurações ou gestão de estoque.

## Arquitetura

O Windows/SQLite continua sendo a autoridade transacional. O Supabase contém apenas vínculos de autenticação, snapshots de leitura e a fila de solicitações. O Windows consulta a fila e processa os comandos localmente. A impressão da cozinha permanece no Windows.

## Etapa A — Criar as tabelas e políticas no Supabase

1. Abra o projeto `cqjorvhkiaqbpalizzvf` no Supabase.
2. Abra **SQL Editor**.
3. Copie e execute o arquivo `supabase/migrations/20261120000100_alengo_remote_access.sql`.
4. Confirme que as tabelas `remote_operator_links`, `remote_state` e `remote_requests` foram criadas.

A migração ativa RLS. Usuários autenticados só podem ler seu vínculo, seu snapshot e suas solicitações. Só podem inserir solicitações próprias. O Windows usa a Secret Key no servidor para processar a fila e publicar snapshots.

## Etapa B — Criar o usuário remoto de cada atendente

Para cada atendente autorizado:

1. No Supabase, abra **Authentication → Users → Add user**.
2. Cadastre o e-mail do atendente e uma senha própria para o acesso remoto.
3. Confirme o e-mail no cadastro administrativo (não é a senha local do PDV).
4. Copie o UUID do usuário criado.

O login remoto utiliza e-mail e senha do Supabase Auth. O login local da porta 8765 continua utilizando usuário e senha do PDV.

## Etapa C — Configurar a Secret Key no Windows

1. Instale/atualize o Windows com o pacote 1.5.0.
2. No computador que executa o PDV, abra PowerShell na pasta do projeto extraído.
3. Execute:

   ```powershell
   powershell -ExecutionPolicy Bypass -File .\scripts\CONFIGURAR-ALENGO-REMOTO.ps1
   ```

4. Quando solicitado, cole a Secret Key `sb_secret_` exclusiva do ALENGO.
5. A chave é protegida pelo DPAPI do Windows para o usuário atual e gravada em:

   `%APPDATA%\ALENGO-ESPETOS\alengo-remote.json`

6. Feche e abra o ALENGO ESPETINHOS usando a mesma conta Windows que executou o script.
7. Mantenha o computador conectado à internet. O servidor inicia a sincronização automaticamente.

**Não copie a Secret Key para `mobile-web/config.js`, para `cloudflare-pages/config.js`, para o navegador ou para o ZIP.** A Publishable Key já está nos arquivos públicos e pode ser distribuída com RLS ativo.

## Etapa D — Vincular o usuário remoto ao operador local

Depois de iniciar o Windows com a configuração remota, aguarde até 15 segundos. O servidor cria/atualiza:

`%APPDATA%\ALENGO-ESPETOS\alengo-remote-operators.json`

Esse arquivo lista `id`, `name`, `role` e `active` dos operadores locais, sem incluir senhas.

No Supabase SQL Editor, substitua os valores e execute:

```sql
insert into public.remote_operator_links (auth_user_id, operator_id, active)
values ('UUID-DO-USUARIO-SUPABASE', ID-DO-OPERADOR-WINDOWS, true)
on conflict (auth_user_id)
do update set operator_id = excluded.operator_id, active = true;
```

Somente operadores locais ativos com perfil `operator` são aceitos. Administradores locais não recebem acesso remoto.

Para revogar um atendente:

```sql
update public.remote_operator_links
set active = false
where auth_user_id = 'UUID-DO-USUARIO-SUPABASE';
```

## Etapa E — Publicar o aplicativo Web remoto

A pasta `cloudflare-pages/` é a versão Web estática para publicação HTTPS. Ela já contém a URL do projeto e a Publishable Key; não contém a Secret Key.

### Publicação pelo painel Cloudflare

1. Entre no Cloudflare Dashboard.
2. Abra **Workers & Pages → Create application → Pages → Direct Upload** (o nome pode variar conforme a interface).
3. Crie o projeto `alengo-espetinhos-atendimento`.
4. Envie o ZIP `ALENGO-ESPETINHOS-1.5.0-WEB-REMOTO-CLOUDFLARE.zip` ou a pasta `cloudflare-pages/` (não envie a pasta Windows inteira).
5. Aguarde a publicação e copie o endereço `https://....pages.dev` gerado.

### Alternativa pelo terminal

Com Node.js instalado, o script `DEPLOY-CLOUDFLARE-PAGES.bat` autentica no Cloudflare, cria o projeto Pages (se ainda não existir) e publica a pasta. Também é possível executar manualmente:

```powershell
npx wrangler login
npx wrangler pages project create alengo-espetinhos-atendimento --production-branch main
npx wrangler pages deploy .\cloudflare-pages --project-name alengo-espetinhos-atendimento
```

Se o projeto já existir, pule o comando `pages project create` e execute somente o deploy.

No Supabase, abra **Authentication → URL Configuration** e configure o endereço Pages como Site URL e como URL permitida, por exemplo `https://alengo-espetinhos-atendimento.pages.dev/**`.

O endereço publicado abre diretamente no modo Internet. O atendente pode adicioná-lo à tela inicial do iPhone ou Android.

## Como o fluxo funciona

1. O atendente entra com e-mail/senha do Supabase Auth.
2. O Web lê o último snapshot permitido pelo RLS.
3. Ao enviar pedido, cancelar ou atualizar entrega, grava uma solicitação própria na fila remota.
4. O Windows busca a fila, valida o vínculo com o operador local e aplica a operação no SQLite.
5. O Windows atualiza o status para `CONFIRMED` ou `ERROR`.
6. O Web só apresenta sucesso quando recebe `CONFIRMED`.

Se o celular perder internet fora da rede local, as operações ficam no IndexedDB e são reenviadas quando a conexão retornar. Enquanto não houver confirmação do Windows, o pedido permanece **pendente**, não é impresso e não deve ser tratado como recebido pela cozinha.

## Testes antes de produção

- Login local pela porta 8765 e login remoto pelo Pages.
- Login remoto com usuário sem vínculo (deve ser negado).
- Usuário remoto vinculado a operador desativado (deve ser negado pelo Windows).
- Pedido remoto com estoque disponível e impressão na cozinha.
- Pedido com estoque insuficiente (deve retornar erro sem baixa parcial).
- Reenvio da mesma solicitação (não deve duplicar pedido/estoque).
- Entrega parcial, incremento/decremento e limite de quantidade.
- Cancelamento antes de qualquer entrega e estorno de estoque apenas uma vez.
- Cancelamento após entrega (deve ser recusado).
- Windows desligado/internet interrompida, fila pendente e retomada.
- Web offline com snapshot anterior, fechamento/reabertura do navegador e sincronização posterior.
- Android local permanece funcional e impressão permanece local.

## Limitações e itens que exigem configuração no ambiente do usuário

- O SQL precisa ser executado no projeto Supabase.
- Usuários Auth e vínculos com operadores precisam ser cadastrados.
- A Secret Key precisa ser configurada localmente no Windows com o script DPAPI.
- O diretório `cloudflare-pages/` precisa ser publicado em um host HTTPS; a entrega do código não publica o site na conta Cloudflare automaticamente.
- O acesso remoto exige Windows ligado e conectado à internet. Se o Windows estiver desligado, os comandos ficam pendentes e não chegam à cozinha.
- O snapshot é atualizado periodicamente (aprox. 10 segundos) e o Web consulta atualizações em intervalos de aproximadamente 15 segundos; esta primeira entrega usa polling controlado, não Supabase Realtime.
- Notificações push/alertas do aplicativo Android local não foram estendidas ao Web remoto nesta versão; o estado dos pedidos é atualizado pelo snapshot.
- O app Web pode usar dados de snapshot em cache offline, mas não consegue garantir atualização de mesas/estoque sem comunicação com o Windows.
