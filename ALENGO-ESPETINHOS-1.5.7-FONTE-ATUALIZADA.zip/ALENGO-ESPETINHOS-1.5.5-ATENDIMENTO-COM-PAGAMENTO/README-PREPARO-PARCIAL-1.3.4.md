# Preparo parcial por item — 1.3.4

- Cada item da comanda registra `delivered_quantity`, com auditoria de cada alteração em `restaurant_order_item_events`.
- Windows e celular usam o mesmo endpoint transacional; o aplicativo móvel só altera pedidos criados pelo próprio operador/aparelho.
- A quantidade entregue nunca pode exceder a quantidade pedida ou ficar negativa.
- A comanda só recebe `ready_at` quando a soma das unidades entregues alcançar a soma das unidades pedidas.
- O botão Windows `Marcar tudo entregue` é um atalho que atualiza todos os itens de uma vez.
- Pedidos antigos marcados como prontos são migrados como integralmente entregues.
- O pagamento e a baixa de estoque não são modificados pelo andamento de entrega.
- O cancelamento integral é bloqueado depois da primeira unidade entregue, para não devolver estoque já consumido.

Testes: execute `node tests/restaurante.test.cjs` e `node tests/migracao-preparo-parcial.test.cjs` a partir da raiz do pacote.
