# Relatório de verificação — ALENGO ESPETINHOS 1.5.1

## Alterações
- Login remoto por nome do operador e senha, sem e-mail informado pelo atendente.
- Controle individual em Configurações > Operadores.
- Windows provisiona/atualiza o usuário interno do Supabase Auth com a Secret Key local.
- Vínculo Auth UUID ↔ operador é criado automaticamente pelo Windows.
- Desmarcar acesso remoto desativa o vínculo e bane a conta remota; reativar atualiza o mesmo usuário.
- Senha remota deve ter no mínimo 6 caracteres; redefinição pelo campo Senha no cadastro do operador.
- Contas antigas do fluxo manual deixam de ter vínculo após a nova migração.
- Android permanece sem alterações funcionais; mobile-web local recebe apenas o mesmo formulário de login por usuário.

## Verificações executadas
- `node --check` em electron/remote-bridge.js, electron/restaurant.js, electron/main.js, cloudflare-pages/app.js e mobile-web/app.js: aprovado.
- `node --test tests/remote-access-contract.test.cjs`: 8/8 aprovados.
- Configuração pública Cloudflare: contém apenas URL do projeto e Publishable Key; nenhuma Secret Key.
- Revisão estrutural do fluxo de login e sincronização de operadores: concluída.

## Não executado / necessário para homologação
- Build do instalador Windows x64: deve ser executado em Windows com Node/Electron e dependências nativas instaladas.
- SQL migration 1.5.1: ainda deve ser executada pelo usuário no Supabase.
- Configuração DPAPI da Secret Key no Windows: ainda não confirmada nesta versão.
- Deploy Cloudflare Pages atualizado: ainda não executado.
- Teste real de criação/alteração/bloqueio de usuário Supabase Auth, login em navegador, envio de pedido e processamento Windows: pendente.
- Testes de impressora e regressão completa do PDV: pendentes.

**Status:** código-fonte adaptado e verificações estáticas aprovadas. Não declarar homologado ou pronto para produção antes dos testes reais acima.
