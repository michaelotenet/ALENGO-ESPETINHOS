# ALENGO ESPETINHOS 1.5.3 — Painel de Operações e janela Sobre

## Novidades

- Nova opção em **Configurações → Interface e facilidade de uso → Tela inicial do computador**:
  - Interface atual — menu lateral (padrão, preserva a experiência anterior).
  - Painel de Operações — cartões organizados por Operação, Cadastros, Gestão e Sistema.
- Os cartões usam acentos de ícones alternados e discretos, mantendo o fundo, superfícies, tipografia e tema selecionado pelo sistema.
- O painel respeita as permissões do operador, os módulos habilitados e o modo Essencial/Completo.
- Para retornar ao painel depois de abrir um módulo, use **← Painel de Operações** no cabeçalho.
- A preferência é gravada nas configurações do sistema e permanece após reiniciar.
- Janela **Sobre** sem menu superior; mantém a logo atual e adapta fundo, painel, texto e cor de destaque ao tema selecionado.
- A linha inferior da janela Sobre passa a exibir somente **Uni-Softwares 2026**, removendo “Desenvolvido em 2026”.

## Atualização

1. Faça backup do banco SQLite pelo módulo Backup.
2. Extraia o pacote de código-fonte em uma pasta separada.
3. Execute `BUILD-ALENGO-ESPETINHOS-WINDOWS.bat` em um computador Windows compatível para gerar o instalador x64.
4. Instale a atualização e escolha o painel em Configurações.

Nenhuma migração SQL é necessária para esta preferência: ela é armazenada na tabela `settings` existente. O valor padrão é `sidebar`, portanto instalações existentes continuam com a interface atual até que o administrador escolha o Painel de Operações.

## Escopo e validação

- Alterações concentradas na interface Windows e na janela Sobre.
- Não foram alterados o aplicativo Android, o site de atendimento, a sincronização remota, o fluxo de pedidos ou as regras de banco de dados.
- Os 13 testes automatizados passaram.
- `electron/main.js` passou em `node --check`.
- O build Vite/React e o instalador Windows não foram executados neste ambiente, pois as dependências não ficaram disponíveis durante a instalação (`npm ci` excedeu o tempo limite). O build deve ser feito no Windows usando o BAT incluído antes de homologar em produção.
