# Relatório de QA — ALENGO ESPETINHOS 1.5.3

## Alterações verificadas
- Preferência `ux_home_layout` adicionada aos defaults do SQLite, com valor seguro `sidebar`.
- Configurações oferece escolha entre sidebar e Painel de Operações.
- Painel agrupa os atalhos por categorias e deriva a lista de módulos visíveis das permissões, modo Essencial/Completo e módulos habilitados.
- Cartões mantêm superfícies e cores de tema, com cores alternadas apenas nos ícones.
- Cabeçalho permite retornar ao painel quando um módulo está aberto.
- Janela Sobre chama `setMenu(null)` e `setMenuBarVisibility(false)`, usa paleta conforme o tema salvo e mantém o recurso de logo existente.
- Texto final da janela Sobre: `Uni-Softwares 2026`.

## Testes executados
- `node --check electron/main.js`: aprovado.
- `node --test tests/*.test.cjs`: 13/13 aprovados.

## Não executado
- Compilação Vite/React/JSX e instalador Windows x64: dependências não disponíveis; `npm ci --ignore-scripts --prefer-offline` excedeu o tempo limite.
- Teste visual em Windows e validação manual de todos os temas: pendentes.

**Status:** QA estrutural aprovado; build e homologação visual no Windows ainda necessários.
