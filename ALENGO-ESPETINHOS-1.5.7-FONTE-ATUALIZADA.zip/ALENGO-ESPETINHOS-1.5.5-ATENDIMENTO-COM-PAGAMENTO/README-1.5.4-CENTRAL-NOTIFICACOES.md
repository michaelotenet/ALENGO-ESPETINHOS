# ALENGO ESPETINHOS 1.5.4 — Central unificada de notificações

## O que foi incluído

- Histórico persistente de notificações no SQLite do Windows, com chave de evento única.
- Separação de destinatários: `WINDOWS` para novos pedidos recebidos e `OPERATOR` para atualizações de preparo destinadas ao operador responsável.
- Aviso nativo do Windows (visual e som padrão do sistema) quando um pedido novo é recebido e salvo pelo PDV.
- Notificação ao operador quando uma alteração de preparo feita no Windows libera unidades de um item, com classificação parcial/completa, identificação do pedido, mesa/retirada, cliente e item.
- Histórico de notificações no site local e no Cloudflare Pages, com contador de não lidas e ação de marcar como lidas.
- Snapshot remoto inclui somente notificações do operador autenticado. A leitura é confirmada pela fila de comandos autenticada do Supabase.
- A central de notificações do Windows exibe os novos pedidos recebidos e mantém o histórico no banco local.
- Eventos antigos e novos alertas legados continuam preservados; a migração é aditiva.

## Atualização do Supabase

Execute no SQL Editor do projeto Supabase exclusivo do ALENGO:

`supabase/migrations/20261120000300_alengo_notification_center.sql`

A migração ajusta a restrição de tipos da fila `remote_requests` para permitir `ACK_NOTIFICATION`. Não apaga pedidos, operadores, vínculos ou snapshots.

## Atualização do Windows

1. Faça backup do banco SQLite.
2. Extraia o código-fonte em uma pasta separada.
3. Execute `BUILD-ALENGO-ESPETINHOS-WINDOWS.bat`.
4. Instale o Setup 1.5.4 no computador servidor.
5. Mantenha o Windows ligado e conectado à internet para sincronização remota.

A tabela de notificações é criada automaticamente na primeira inicialização. A Secret Key protegida existente não precisa ser configurada novamente.

## Atualização do site

Publique os oito arquivos do pacote `ALENGO-ATENDIMENTO-1.5.4-CLOUDFLARE-PAGES.zip` no projeto Pages existente `alengo-atendimento`.

O pacote também atualiza o cache do Service Worker. No celular, feche e abra novamente o atalho/site após o deploy.

## Funcionamento e limites conhecidos

- A notificação do navegador pode ser exibida quando a página permanece aberta em segundo plano, o navegador mantém a execução e o usuário concede permissão. O aviso sonoro da página depende de interação prévia do usuário para liberar áudio.
- O acesso local por HTTP via IP não é contexto seguro para a API de notificações do navegador; nesse modo, o histórico e os avisos internos do site continuam disponíveis, e o som pode depender das restrições do navegador.
- Push do navegador com a página totalmente fechada não está habilitado nesta entrega: isso exige provisionamento de chaves VAPID e um serviço de envio push. Não confundir com notificações enquanto a página está aberta/em segundo plano.
- O alerta do Windows usa a notificação nativa do Electron/Windows e o som padrão configurado no sistema.
- A confirmação de leitura remota é enfileirada como comando autenticado e aplicada pelo Windows. Se o Windows estiver offline, a confirmação fica pendente no aparelho até a reconexão.
- A semântica de preparo usa o controle existente de quantidade pronta/entregue (`delivered_quantity`). A notificação identifica a alteração e o total liberado; não cria uma nova coluna independente de preparo.

## Testes realizados

- `node --check` nos arquivos JavaScript do Electron e das duas versões Web.
- `node --test tests/*.test.cjs`.
- Verificação da integridade dos ZIPs de entrega.

Não foi possível gerar o instalador Windows nem executar build Vite/React nesta sessão, pois o pacote recebido não continha `node_modules`. Também não foram executados testes de integração com o projeto Supabase/Cloudflare real, nem testes físicos de toast/áudio no Windows ou celulares. A homologação final deve ocorrer após o deploy e a instalação em ambiente de teste.
