# Relatório de verificação — ALENGO ESPETINHOS 1.5.2

## Alterações
- Preservação de foco/cursor durante renderizações automáticas do Web.
- Snapshot remoto e endpoint local fornecem somente id, nome e telefone dos clientes cadastrados.
- Campo de cliente usa autocomplete, mantendo a possibilidade de digitar um nome avulso.
- Pedido salva `customer_id` quando selecionado um cadastro válido; a venda originada da comanda herda o vínculo somente quando todos os pedidos recebidos compartilham o mesmo cliente.
- Migração aditiva SQLite cria `restaurant_orders.customer_id` sem apagar pedidos existentes.
- Cache do Service Worker atualizado para v3.

## Verificações executadas
- `node --check` em `electron/restaurant.js`, `cloudflare-pages/app.js` e `mobile-web/app.js`.
- Testes automatizados do contrato remoto.
- Integridade dos ZIPs de entrega.

## Não homologado nesta execução
- Build Vite/React e instalador Windows x64.
- Login real no Supabase e publicação Cloudflare.
- Teste ponta a ponta com banco Windows, seleção de cliente, baixa de estoque e impressão física.

A instalação Windows deve ser atualizada para 1.5.2 para disponibilizar os clientes no snapshot e persistir o vínculo do cliente no pedido. Faça backup do SQLite antes da atualização.
