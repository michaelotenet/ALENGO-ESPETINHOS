# ALENGO ESPETINHOS 1.5.1 — acesso remoto administrado pelo Windows

## Modelo de acesso
- Não há cadastro de atendente no site nem e-mail.
- O administrador cadastra o operador em **Configurações > Operadores**.
- Para habilitar o site, marque **Permitir acesso remoto pelo site** e informe uma senha com pelo menos 6 caracteres.
- O atendente entra em `https://alengo-atendimento.pages.dev` com o mesmo nome e a senha configurados no Windows.
- Para redefinir a senha remota, edite o operador, informe a nova senha e salve.
- Para revogar o acesso remoto, desmarque a opção e salve. Desativar o operador também revoga a sessão/acesso remoto.

## Configuração
1. Faça backup do banco de dados do Windows.
2. Execute no Supabase SQL Editor a migração `supabase/migrations/20261120000200_operator_managed_auth.sql`. Ela desativa os vínculos do modelo antigo por e-mail/UUID.
3. Mantenha a Secret Key configurada localmente no Windows com `scripts/CONFIGURAR-ALENGO-REMOTO.ps1`. Nunca a coloque no site.
4. Publique o conteúdo da pasta `cloudflare-pages/` no projeto Cloudflare Pages `alengo-atendimento`.
5. Configure a URL `https://alengo-atendimento.pages.dev` no Auth URL Configuration do Supabase como Site URL e Redirect URL permitida (a autenticação por senha não depende de confirmação por e-mail, mas manter a URL autorizada evita incompatibilidades).
6. Atualize o Windows para 1.5.1 somente após backup e homologação local.
7. Abra o ALENGO e, em **Configurações > Operadores**, habilite individualmente os atendentes que terão acesso remoto.

## Segurança e operação
- O identificador remoto é derivado do nome do operador por SHA-256; o e-mail sintético `@alengo.invalid` é interno e não é mostrado nem usado para enviar e-mail.
- A senha é provisionada pelo Windows diretamente no Supabase Auth usando a Secret Key local protegida por DPAPI.
- A Secret Key nunca é enviada ao navegador.
- Operadores administradores não recebem acesso ao atendimento remoto.
- O Windows continua validando pedidos, estoque e permissões e grava no SQLite. Se o Windows estiver desligado ou sem internet, pedidos remotos ficam pendentes.
- A desativação do vínculo antigo no SQL é necessária para impedir que contas do fluxo anterior continuem acessando.
- O login remoto exige senha de pelo menos 6 caracteres; a senha local existente continua respeitando as regras locais quando o acesso remoto não está habilitado.

## Limites da homologação
Os testes automatizados e verificações estáticas não substituem a homologação com Supabase e Cloudflare reais. Após a publicação, testar login autorizado, senha incorreta, operador sem acesso remoto, operador desativado, redefinição de senha, envio de pedido, falta de estoque, duplicidade, Windows offline e retorno da conexão.
