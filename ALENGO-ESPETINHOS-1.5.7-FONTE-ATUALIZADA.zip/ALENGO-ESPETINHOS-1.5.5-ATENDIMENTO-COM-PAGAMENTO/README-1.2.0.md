# ALENGO ESPETINHOS 1.2.0 — Pedidos no salão e para retirada

- As comandas de **Mesa** e **Retirada** são impressas na mesma impressora da cozinha, sinalizadas no cabeçalho.
- O PDV tem a fila de **Retirada** separada da lista de mesas. As retiradas são cobradas individualmente.
- Em Pedidos, o caixa pode clicar em **Avisar que está pronto** para enviar um alerta ao celular de origem. Também é permitido avisar depois de o cliente pagar. O alerta não muda o status financeiro.
- Celulares podem usar uma sessão local persistente individual, sem PIN. O operador entra uma vez com IP, usuário e senha; o aplicativo guarda o token de sessão no armazenamento seguro do aparelho. Não há armazenamento em texto da senha.
- Para revogar todas as sessões móveis: **Pedidos > Integração com celulares > Revogar acessos móveis** (somente administrador).
- O nome ALENGO / ESPETINHOS foi separado em duas linhas na sidebar.
- A migração do banco 1.1 para 1.2 preserva mesas, pedidos, itens e comprovantes (teste automatizado em SQLite). Faça backup antes de instalar.
- Os dois tipos de impressoras continuam independentes.
- O arquivo `mobile/eas.json` contém o perfil `preview` para gerar APK via EAS.

## Limitações do piloto

O app consulta a rede local para receber avisos enquanto está aberto. Para aviso com o aplicativo em segundo plano ou encerrado, é necessário que o celular e o computador tenham acesso à internet, permissões de notificação e credenciais Android FCM / Apple APNs configuradas no EAS. A entrega de notificações push não é garantida em qualquer estado de energia, permissões ou rede. O envio de push é tentado sem bloquear o comando do caixa.

O protocolo da API local ainda é **HTTP sem TLS**, inclusive no login inicial. **Não utilizar em produção sem proteção de transporte/autenticação adicional.**

A impressão real em hardware, o instalador Windows e o APK/IPA não foram construídos/homologados neste ambiente.

## Hotfix 1.2.1
A fila 'Pedidos aguardando preparo' aparece no topo do menu Pedidos. O botão de pronto funciona inclusive nos pedidos pagos e nos pedidos criados no Windows (sem celular, apenas registra como pronto). Para notificar o aparelho de origem, o pedido deve ter sido enviado pelo aplicativo móvel. A marca ALENGO / ESPETINHOS tem espaço próprio abaixo do controle de expansão. É obrigatório recompilar/instalar o Windows para ver estas correções.
