# ALENGO ESPETINHOS Windows — versão 1.4.0

## Escopo

Esta atualização altera somente o aplicativo Windows. O projeto `mobile/` foi mantido sem alterações.

## Novos menus

- **Análise de Vendas:** ranking de itens por quantidade e valor, com filtros diário, semanal, mensal e intervalo de datas.
- **Itens Internos:** cadastro independente de ingredientes/insumos, com categorias, subcategorias, visualização e cadastro em lote. Unidades são livres (g, kg, ml, L, un etc.) e aceitam quantidades fracionadas.
- **Análise de Estoque:** saídas, entradas e produtos sem giro no intervalo escolhido.
- **Rentabilidade:** total vendido, recebimentos, custos cadastrados, lucro bruto estimado, margem sobre recebimentos e contas a receber.
- **Metas Financeiras:** meta diária, semanal ou mensal; progresso usa os recebimentos registrados e estima o lucro proporcionalmente aos custos cadastrados.

## Composição de produtos

No cadastro/edição de um produto existe uma seção opcional **Composição / Ingredientes internos**. A quantidade cadastrada representa o consumo por unidade vendida; em produtos vendidos por peso, representa o consumo por kg. Exemplo: para uma guarnição vendida em porções de 250 g, cadastre 250 g de mandioca crua por porção.

O estoque dos ingredientes é baixado quando o pedido é criado (comanda Windows ou aplicativo) ou quando uma venda de balcão é concluída. Pedidos abertos cancelados antes da entrega estornam os ingredientes. Vendas canceladas estornam composições baixadas diretamente pela venda. O consumo fica registrado em histórico separado.

**Atenção sobre custos:** o custo por unidade do item interno é informado na mesma unidade de estoque (por exemplo, custo por grama quando o estoque é controlado em gramas). O campo Custo do produto continua sendo considerado no cálculo de rentabilidade, somado ao custo dos ingredientes da composição.

## Dados e segurança

As tabelas novas são criadas automaticamente no banco existente; nenhum dado anterior é apagado. O cadastro de ingredientes, alteração de composição, movimentações manuais e metas é restrito ao perfil administrador.

## Gerar instalador Windows

Na pasta `desktop`, execute `BUILD-ALENGO-ESPETINHOS-WINDOWS.bat`. O instalador será gerado em `desktop/release/`. A instalação deve ser testada primeiro em uma cópia/ambiente de homologação e com backup atualizado do banco.

## Validação desta entrega

- Testes automatizados existentes: 7/7 aprovados.
- Teste de contrato da nova funcionalidade: incluído em `tests/novos-menus-140.test.cjs`.
- Sintaxe JavaScript do processo principal, preload e módulo de pedidos: verificada com `node --check`.
- Sintaxe JSX: verificada com o compilador TypeScript em modo transpile.
- O empacotamento Vite/Electron não foi executado neste ambiente porque o acesso ao npm registry estava indisponível. Execute o `.bat` em Windows com internet para instalar dependências e gerar o instalador.
