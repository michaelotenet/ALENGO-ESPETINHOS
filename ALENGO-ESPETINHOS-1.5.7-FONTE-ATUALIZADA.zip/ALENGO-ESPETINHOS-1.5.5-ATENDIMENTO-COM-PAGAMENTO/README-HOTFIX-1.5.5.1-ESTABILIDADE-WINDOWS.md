# ALENGO ESPETINHOS 1.5.6 (hotfix da 1.5.5.1) — estabilidade no Windows

## Correções
- Campos de login agora recebem digitação diretamente pelo navegador, sem atualizar estado React a cada tecla. A validação e autenticação ocorrem no envio do formulário.
- Removida a chamada síncrona `execFileSync` que podia bloquear o processo principal do Electron durante a descriptografia DPAPI da chave remota. A leitura de configuração e a execução do PowerShell passaram a ser assíncronas.
- Simplificados os efeitos visuais da tela de login para reduzir custo de composição gráfica.
- Nenhuma migração SQL é necessária. Nenhuma alteração foi feita no Android 1.3.4 ou no pacote Cloudflare Pages.

## Compilação
Extraia o pacote em uma pasta nova no Windows 10/11, abra PowerShell nessa pasta e execute:

```powershell
.\BUILD-ALENGO-ESPETINHOS-WINDOWS.bat
```

O instalador será gerado em `release`. Faça cópia de segurança da pasta de dados antes de instalar. O hotfix não apaga nem recria o banco de dados.

## Validação realizada neste pacote
- 24 testes automatizados de contrato/regressão passaram.
- Sintaxe JavaScript de `electron/remote-bridge.js` validada com `node --check`.
- Integridade e consistência do ZIP verificadas.
- A compilação Vite/Electron e a experiência de digitação precisam ser confirmadas em Windows 10 real; não foram homologadas neste ambiente.


## Correção adicional de empacotamento
A versão interna do pacote foi normalizada para SemVer `1.5.6`, pois `1.5.5.1` possui quatro componentes numéricos e é rejeitada pelo electron-builder. O ícone inexistente `ClipboardClock` foi substituído por `ClipboardList`.
