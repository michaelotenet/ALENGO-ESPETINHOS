# Relatório de QA — ALENGO ESPETINHOS 1.5.0

## Verificações executadas neste ambiente

- `npm test`: 5/5 testes de contrato estrutural aprovados.
- `node --check electron/restaurant.js`: aprovado.
- `node --check electron/remote-bridge.js`: aprovado.
- `node --check mobile-web/app.js`: aprovado.
- `node --check mobile-web/config.js`: aprovado.
- `node --check mobile-web/sw.js`: aprovado.
- `node --check cloudflare-pages/app.js`: aprovado.
- `node --check cloudflare-pages/config.js`: aprovado.
- `node --check cloudflare-pages/sw.js`: aprovado.
- `package.json` e `package-lock.json`: JSON válido.
- Inspeção estática confirmou que a Secret Key não está nos arquivos públicos do Web.

## O que os testes cobrem

1. Presença das tabelas e políticas RLS da migração Supabase.
2. Uso apenas da Publishable Key no cliente Web.
3. Leitura da Secret Key protegida por DPAPI no servidor Windows.
4. Uso de IndexedDB para fila remota persistente e confirmação explícita pelo Windows.
5. Encaminhamento de pedidos, entregas e cancelamentos para as rotinas transacionais já existentes no SQLite.

## O que não foi possível homologar neste ambiente

- A migração SQL ainda não foi executada no projeto Supabase do usuário.
- A Secret Key exclusiva não foi fornecida nem configurada neste ambiente (corretamente, ela não deve ser enviada pelo chat).
- Nenhum usuário Supabase Auth ou vínculo remoto foi criado.
- O aplicativo Web ainda não foi publicado no Cloudflare Pages.
- Não foi realizada uma chamada real de ponta a ponta entre Supabase, Windows e celular.
- Não foi gerado instalador Windows x64: a compilação final deve ser executada no Windows do projeto para validar o pacote Electron e os módulos nativos SQLite.
- Os testes apresentados são testes automatizados de contrato/estrutura e verificação de sintaxe, não substituem a homologação funcional em loja.

## Critério para liberar produção

Executar os passos de configuração do `README-1.5.0-ACESSO-REMOTO.md` e concluir a bateria de testes ponta a ponta, principalmente estoque, idempotência, entrega parcial, cancelamento, reenvio offline e impressão na cozinha. Até essa homologação, manter a versão atual de produção instalada.
